package com.studentCredWithDb.studentCredWithDb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCredWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentCredWithDbApplication.class, args);
	}

}
