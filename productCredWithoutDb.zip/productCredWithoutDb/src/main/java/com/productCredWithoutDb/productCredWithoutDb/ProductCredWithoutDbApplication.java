package com.productCredWithoutDb.productCredWithoutDb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCredWithoutDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCredWithoutDbApplication.class, args);
	}

}
